Exported at 2026-03-23T17:50:17Z

Query: quality_grade=any&identifications=any&place_id=1930&taxon_id=41663&verifiable=true&spam=false

Columns:
id: Unique, sequential identifier for the observation
uuid: Universally unique identifier for the observation. See https://datatracker.ietf.org/doc/html/rfc9562
observed_on: Normalized date of observation
time_observed_at: Normalized datetime of observation
time_zone: Time zone of observation
created_at: Datetime observation was created
quality_grade: Quality grade of this observation. See Help section for details on what this means. See https://help.inaturalist.org/support/solutions/articles/151000169936
place_guess: Locality description as entered by the observer
latitude: Publicly visible latitude from the observation location
longitude: Publicly visible longitude from the observation location
positional_accuracy: Coordinate precision (yeah, yeah, accuracy != precision, poor choice of names)
private_place_guess: Observation location as written by the observer if location obscured
private_latitude: Private latitude, set if observation private or obscured
private_longitude: Private longitude, set if observation private or obscured
public_positional_accuracy: Maximum horizontal positional uncertainty in meters; includes uncertainty added by coordinate obscuration
geoprivacy: Whether or not the observer has chosen to obscure or hide the coordinates. See https://help.inaturalist.org/support/solutions/articles/151000169938
taxon_geoprivacy: Most conservative geoprivacy applied due to the conservation statuses of taxa in current identification.
coordinates_obscured: Whether or not the coordinates have been obscured, either because of geoprivacy or because of a threatened taxon
positioning_method: How the coordinates were determined
positioning_device: Device used to determine coordinates
species_guess: Plain text name of the observed taxon; can be set by the observer during observation creation, but can get replaced with canonical, localized names when the taxon changes
scientific_name: Scientific name of the observed taxon according to iNaturalist
common_name: Common or vernacular name of the observed taxon according to iNaturalist
iconic_taxon_name: Higher-level taxonomic category for the observed taxon
taxon_id: Unique, sequential identifier for the observed taxon

For more information about column headers, see https://www.inaturalist.org/terminology

